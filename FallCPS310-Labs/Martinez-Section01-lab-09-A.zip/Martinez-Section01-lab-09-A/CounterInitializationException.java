public class CounterInitializationException extends RuntimeException
{
    public CounterInitializationException(String reason)
    {
        super(reason);
    }
}